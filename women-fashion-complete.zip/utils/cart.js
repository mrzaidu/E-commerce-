import { createContext, useContext, useEffect, useState } from 'react'
const CartContext = createContext()
export function CartProvider({ children }) {
  const [cart,setCart]=useState([])
  useEffect(()=>{ const s=localStorage.getItem('cart'); if(s)setCart(JSON.parse(s)) },[])
  useEffect(()=>{ localStorage.setItem('cart',JSON.stringify(cart)) },[cart])
  const add=(p,qty=1)=>{ setCart(c=>{ const f=c.find(x=>x.id===p.id); if(f) return c.map(x=>x.id===p.id?{...x,qty:x.qty+qty}:x); return [...c,{...p,qty}] }) }
  const remove=id=>setCart(c=>c.filter(x=>x.id!==id))
  const clear=()=>setCart([])
  return <CartContext.Provider value={{cart,add,remove,clear}}>{children}</CartContext.Provider>
}
export const useCart=()=>useContext(CartContext)